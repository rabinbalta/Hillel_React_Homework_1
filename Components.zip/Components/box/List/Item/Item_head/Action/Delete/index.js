import React from 'react';

class Delete extends React.Component {
	render() {
		return (
			<button>Delete</button>
		);
	}
}

export default Delete;