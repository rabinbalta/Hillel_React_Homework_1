import React from 'react';

class Edit extends React.Component {
	render() {
		return (
			<button>Edit</button>
		);
	}
}

export default Edit;