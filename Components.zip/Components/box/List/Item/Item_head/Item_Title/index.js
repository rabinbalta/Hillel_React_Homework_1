import React from 'react';

class Item_Title extends React.Component {
	render() {
		return (
			<h3></h3>
		);
	}
}

export default Item_Title;