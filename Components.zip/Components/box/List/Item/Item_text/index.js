import React from 'react';

class Item_Text extends React.Component {
	render() {
		return (
			<p></p>
		);
	}
}

export defoul Item_Text;