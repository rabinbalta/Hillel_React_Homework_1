import React from 'react';

class Comment_Input extends React.Component {
	render() {
		return (
			<textarea></textarea>
		);
	}
}

export default Comment_Input;