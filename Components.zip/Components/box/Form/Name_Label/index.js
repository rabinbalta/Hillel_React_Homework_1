import React from 'react';

class Name_Label extends React.Component {
	render() {
		return (
			<label></label>
		);
	}
}

export default Name_Label;