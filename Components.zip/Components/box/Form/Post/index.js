import React from 'react';

class Post extends React.Component {
	render() {
		return (
			<button>post</button>
		);
	}
}

export default Post;