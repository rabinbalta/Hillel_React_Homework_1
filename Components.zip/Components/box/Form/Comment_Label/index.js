import React from 'react';

class Comment_Label extends React.Component {
	render() {
		return (
			<label></label>
		);
	}
}

export default Comment_Label;