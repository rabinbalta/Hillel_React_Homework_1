import React from 'react';

class Name_Input extends React.Component {
	render() {
		return (
			<input type='text'></input>
		);
	}
}

export default Name_Input;